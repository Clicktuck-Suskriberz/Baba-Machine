Baba Machine version 1.5
Cell rules:

   Generator:
	Not added yet
   Mover:
	Mover is push
	Powered mover is auto
	Not powered mover on tile is auto
   Push:
	Pusher is push
   Slider:
	Slider is push
	Powered slider facing (direction) is locked (to perpendicular directions)
   Enemy:
	Enemy is sink
	Level without enemy is win
   Trash:
	Trash eat all
   Immobile:
	Powered immobile is stop
   Fall:
	Fallcell is push
	Powered fallcell is fall(down)

Notes:
-Fall cell doesn't have directional sprites, to mirror the fact that it can only face downwards in Cell Machine Mystic Mod Plus
-Rotations behave like they do in normal Baba Is You and not Cell Machine
-There are three custom level slots that don't have anything in them yet, two community levels will be added in version 2