Baba Machine levelmaking kit for Baba Machine version 4
Cell rules:

   Generator:
	Generator generates any cell behind it and has a one turn delay
   Mover:
	Mover is push
	Powered mover is auto
	Not powered mover on tile is auto
   Driller:
	Same as mover but its swap when facing any cell that isn't enemy or immobile
   Push:
	Pusher is push
   Slider:
	Slider is push
	Powered slider facing (direction) is locked (to perpendicular directions)
   Directional:
	Directional is push
	Powered directional facing (direction) can only go in that direction
	Directional is pull in level variant-3
   Enemy:
	Enemy is sink
	Level without enemy is win
	Powered enemy* is still
   Trash:
	Trash eat all
   Immobile:
	Powered immobile is stop
   Fall:
	Fallcell is push
	Powered fallcell is fall(down)
   Repulsor:
	Powered all (except wall, immobile, algae, and skull) fear repulsor
	*Not next to repulsor
   Bread:
	Bread next to two pushers, movers, or a pusher and a mover is sink
   Cellke:
	Cellke is push
	Powered cellke is move

Notes:
-Fall cell doesn't have directional sprites, to mirror the fact that it can only face downwards in Cell Machine Mystic Mod Plus
-Rotations behave like they do in normal Baba Is You and not Cell Machine
-There are three custom level slots that don't have anything in them yet, two community levels will be added in version 2
-Ayo there's a dimensional rift in my levelpack