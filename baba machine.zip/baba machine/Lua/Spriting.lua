table.insert(editor_objlist_order, "test") -- (A)
table.insert(editor_objlist_order, "text_test") -- (A)
editor_objlist["test"] = 
{
	name = "test",
	sprite_in_root = false,
	unittype = "object",
	tags = {"test"},
	tiling = -1,
	type = 0,
	layer = 1,
	colour = {0, 1},
}

editor_objlist["text_test"] = 
{
	name = "text_test",
	sprite_in_root = false,
	unittype = "text",
	tags = {"text","test"},
	tiling = -1,
	type = 0,
	layer = 20,
	colour = {0, 0},
	colour_active = {0, 1},
}

formatobjlist() -- (C)